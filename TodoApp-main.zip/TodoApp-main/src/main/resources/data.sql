insert into todo(id, username,description,target_date,is_done)
values(10001, 'lakshander', 'Complete Task 1', CURRENT_DATE(), false);

insert into todo(id, username,description,target_date,is_done)
values(10002, 'lakshander', 'Complete Task 2', CURRENT_DATE(), false);

insert into todo(id, username,description,target_date,is_done)
values(10003, 'lakshander', 'Complete Task 3', CURRENT_DATE(), false);

insert into todo(id, username,description,target_date,is_done)
values(10004, 'gaurav', 'Complete Task 4', CURRENT_DATE(), false);

insert into todo(id, username,description,target_date,is_done)
values(10005, 'gaurav', 'Complete Task 5', CURRENT_DATE(), false);

insert into todo(id, username,description,target_date,is_done)
values(10006, 'gaurav', 'Complete Task 6', CURRENT_DATE(), false);

insert into todo(id, username,description,target_date,is_done)
values(10007, 'rahul', 'Complete Task 7', CURRENT_DATE(), false);

insert into todo(id, username,description,target_date,is_done)
values(10008, 'rahul', 'Complete Task 8', CURRENT_DATE(), false);

insert into todo(id, username,description,target_date,is_done)
values(10009, 'rahul', 'Complete Task 9', CURRENT_DATE(), false);