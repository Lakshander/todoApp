package com.todoapp.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;


@SpringBootApplication
@OpenAPIDefinition(
		info = @Info(
				title = "ToDo API",
				version = "1.0",
				description = "ToDo API for creating, editing, updatng & deleting todos.",
				contact = @Contact(name="Developers", email= "2136224@cognizant.com")
				
		)
)

public class TodoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoAppApplication.class, args);
	}
	

}


