package com.todoapp.restapi.controllers;

import java.net.URI;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.sun.xml.bind.v2.TODO;
import com.todoapp.restapi.daos.Todo;
import com.todoapp.restapi.daos.TodoJpaRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class TodoJpaResource {


	@Autowired
	private TodoJpaRepository todoJpaRepository;
	
	@Operation(summary = "Get all Todos", description = "Get list of Todos", tags="Get")
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "ToDos Found"),
			@ApiResponse(responseCode = "404", description = "ToDos not found"),
			@ApiResponse(responseCode = "400", description = "Invalid Request format")
		}
	)
	
	@GetMapping("/jpa/users/{username}/todos")
	public List<Todo> getAllTodos(@PathVariable String username) {
		return todoJpaRepository.findByUsername(username);
	}
//**************************************************************
	
	@Operation(summary = "Get Todo by id", description = "Get todo by id", tags="Get")
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "ToDo Found"),
			@ApiResponse(responseCode = "404", description = "Oo coder kal aana"),
			@ApiResponse(responseCode = "400", description = "Invalid Request format")
		}
	)
	
	@GetMapping("/jpa/users/{username}/todos/{id}")
	public Todo getTodo(@PathVariable String username, @PathVariable long id) {
		return todoJpaRepository.findById(id).get();
	}
//*****************************************************************
	
	@Operation(summary = "Delete ToDo", description = "Delete ToDo by id", tags="Delete")
	@ApiResponses(value = {
			
            @ApiResponse(responseCode = "204", description = "ToDo Deleted"),
            @ApiResponse(responseCode = "500", description = "Username or Id does not exist"),
            @ApiResponse(responseCode = "404", description = "Oo coder kal aana"),
			@ApiResponse(responseCode = "400", description = "Invalid Request format")
		}
	)
	
	@DeleteMapping("/jpa/users/{username}/todos/{id}")
	public ResponseEntity<Void> deleteTodo(@PathVariable String username, @PathVariable long id) {
		todoJpaRepository.deleteById(id);
			return ResponseEntity.noContent().build();
	}
//*******************************************************************
	
	@Operation(summary = "Update ToDo", description = "Update todo by id", tags="Update")
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "ToDo Updated"),
			@ApiResponse(responseCode = "404", description = "Oo coder kal aana"),
			@ApiResponse(responseCode = "400", description = "Invalid Request format")
		}
	)
	
	@PutMapping("/jpa/users/{username}/todos/{id}")
	public ResponseEntity<Todo> updateTodo(@PathVariable String username, @PathVariable long id,
			@RequestBody Todo todo) {
		todo.setUsername(username);
		todoJpaRepository.save(todo);
		return new ResponseEntity<Todo>(todo, HttpStatus.OK);
	}
//	********************************************************************
	
	@Operation(summary = "Create ToDo", description = "Create new todo", tags="Post")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "ToDo Created"),
			@ApiResponse(responseCode = "404", description = "Oo coder kal aana"),
			@ApiResponse(responseCode = "400", description = "Invalid Request format")
		}
	)

	@PostMapping("/jpa/users/{username}/todos")
	public ResponseEntity<Void> createTodo(@PathVariable String username, @RequestBody Todo todo) {
		todo.setUsername(username);
		Todo createdTodo = todoJpaRepository.save(todo);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(createdTodo.getId()).toUri();
		return ResponseEntity.created(uri).build();
	}
}
