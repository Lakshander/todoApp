package com.cognizant.genc.cohort57.pod3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.genc.cohort57.pod3.entity.LkpState;

@Repository
public interface SateLookupRepository extends JpaRepository<LkpState, Integer> {

	@Query(value = "SELECT StateId, StateName FROM Lkp_State WHERE IsActive = 1;", nativeQuery = true)
	List<LkpState> getSates();
}
