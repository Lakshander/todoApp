package com.cognizant.genc.cohort57.pod3.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "GymMembershipDetails")
public class GymMembershipDetails {

	@Id
	@GeneratedValue
	@Column(name = "GMD_Id")
	private int id;

	@Column(name = "GMD_Name")
	private String name;

	@Column(name = "GMD_Email")
	private String email;

	@Column(name = "GMD_Phone")
	private long phone;

	@Column(name = "GMD_Gender")
	private String gender;

	@Column(name = "GMD_Age")
	private int age;

	@Column(name = "GMD_Address")
	private String address;

	@Column(name = "GMD_ZipCode")
	private int zipCode;

	@Column(name = "GMD_StateId")
	private int stateId;

	@Column(name = "GMD_CityId")
	private int cityId;

	@Column(name = "GMD_StartDate")
	private Date startDate;

	@Column(name = "GMD_PlanId")
	private int planId;

	@Column(name = "GMD_Amount")
	private double amount;

	@Column(name = "GMD_EndDate")
	private Date endDate;

	public GymMembershipDetails() {
	} // JPA expects default constructor

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

	public int getCityId() {
		return cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
}
