package com.cognizant.genc.cohort57.pod3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cognizant.genc.cohort57.pod3.entity.GymMembershipInfoSP;

public interface GymMembershipInfoSPRepository extends JpaRepository<GymMembershipInfoSP, Integer> {

	@Query(value = "CALL sp_GetGymMembershipInfo();", nativeQuery = true)
	List<GymMembershipInfoSP> getGymMembershipInfo();
}
