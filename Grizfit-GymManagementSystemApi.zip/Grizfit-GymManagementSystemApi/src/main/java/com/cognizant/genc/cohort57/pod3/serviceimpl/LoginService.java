package com.cognizant.genc.cohort57.pod3.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.genc.cohort57.pod3.entity.GymMembershipAppAccount;
import com.cognizant.genc.cohort57.pod3.entity.LkpAppSubscription;
import com.cognizant.genc.cohort57.pod3.model.Account;
import com.cognizant.genc.cohort57.pod3.model.LoginModel;
import com.cognizant.genc.cohort57.pod3.repository.AppSubscriptionLookupRepository;
import com.cognizant.genc.cohort57.pod3.repository.GymMembeshipAppAccountRepository;
import com.cognizant.genc.cohort57.pod3.service.ILoginService;

@Service
public class LoginService implements ILoginService {

	@Autowired
	private GymMembeshipAppAccountRepository _gymMembeshipAppAccountRepository;
	@Autowired
	AppSubscriptionLookupRepository _appSubscriptionLookupRepository;

	@Override
	public LoginModel validateGymOwner(String emailId, String password) {

		GymMembershipAppAccount gymMembershipAppAccount = _gymMembeshipAppAccountRepository.validateGymOwner(emailId,
				password);

		if (gymMembershipAppAccount == null)
			return null;

		LoginModel loginModelObj = new LoginModel();
		loginModelObj.setAccountEmail(gymMembershipAppAccount.getAccountEmail());

		return loginModelObj;
	}

	@Override
	public int createGymAccount(Account account) {

		LkpAppSubscription lkpAppSubscription = _appSubscriptionLookupRepository
				.verifySubscription(account.getSubscriptionKey());
		if (lkpAppSubscription == null)
			return 0;
		int subscriptionId = lkpAppSubscription.getSubscriptionId();
		String accountName = account.getAccountName();
		String accountEmail = account.getAccountEmail();
		String accountPassword = account.getAccountPassword();
		int res = _gymMembeshipAppAccountRepository.createGymAccount(subscriptionId, accountName, accountEmail,
				accountPassword);
		return res;
	}

}
