package com.cognizant.genc.cohort57.pod3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.genc.cohort57.pod3.model.Account;
import com.cognizant.genc.cohort57.pod3.model.LoginModel;
import com.cognizant.genc.cohort57.pod3.service.ILoginService;

@RestController
@CrossOrigin(origins="http://localhost:3000")
@RequestMapping("/api/login")
public class LoginController {

	@Autowired
	private ILoginService _loginService;

	@PostMapping("/validateGymOwner")
	public ResponseEntity<?> validateGymOwner(@RequestBody LoginModel loginModel) {

		String email = loginModel.getAccountEmail();
		String password = loginModel.getAccountPassword();

		try {
			LoginModel loginModelRes = _loginService.validateGymOwner(email, password);
			if (loginModelRes == null)
				throw new Exception("User Not Found, please register or enter correct credentials");
			return new ResponseEntity<>(loginModelRes, HttpStatus.OK);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

	@PostMapping("/createGymAccount")
	public ResponseEntity<?> createGymAccount(@RequestBody Account account) {

		try {
			int res = _loginService.createGymAccount(account);
			if (res == 0)
				throw new Exception("Fail to Create Account, please use correct subscription key");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}
}
