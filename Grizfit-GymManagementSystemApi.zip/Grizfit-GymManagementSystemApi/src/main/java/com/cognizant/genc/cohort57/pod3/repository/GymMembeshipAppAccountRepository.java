package com.cognizant.genc.cohort57.pod3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.genc.cohort57.pod3.entity.GymMembershipAppAccount;

@Repository
public interface GymMembeshipAppAccountRepository extends JpaRepository<GymMembershipAppAccount, Integer> {

	@Query(value = "SELECT * FROM GymMembershipAppAccount as acc WHERE "
			+ "acc.AccountEmail =?1 AND acc.AccountPassword =?2 AND IsActive = 1 ;", nativeQuery = true)
	GymMembershipAppAccount validateGymOwner(String emailId, String password);
	
	@Modifying
	@Transactional
	@Query(value = "INSERT INTO GymMembershipAppAccount(SubscriptionId, AccountName, AccountEmail, AccountPassword) "
			+ "VALUES(:subscriptionId, :accountName, :accountEmail, :accountPassword);", nativeQuery = true)
	int createGymAccount(
			@Param("subscriptionId") int subscriptionId, 
			@Param("accountName") String accountName,
			@Param("accountEmail") String accountEmail,
			@Param("accountPassword") String accountPassword
			);
}
