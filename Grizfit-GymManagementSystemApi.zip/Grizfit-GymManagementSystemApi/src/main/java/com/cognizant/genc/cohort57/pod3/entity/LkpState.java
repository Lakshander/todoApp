package com.cognizant.genc.cohort57.pod3.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Lkp_State")
public class LkpState {

	@Id
	@GeneratedValue
	@Column(name = "StateId")
	private int stateId;

	@Column(name = "StateName")
	private String stateName;

	public LkpState() {
	}

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

}
