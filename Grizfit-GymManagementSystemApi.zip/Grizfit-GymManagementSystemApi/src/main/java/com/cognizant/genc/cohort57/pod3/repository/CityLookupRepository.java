package com.cognizant.genc.cohort57.pod3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.genc.cohort57.pod3.entity.LkpCity;

@Repository
public interface CityLookupRepository extends JpaRepository<LkpCity, Integer> {

	@Query(value = "SELECT * FROM Lkp_City WHERE StateId = ?1 AND IsActive = 1;", nativeQuery = true)
	List<LkpCity> getCities(int stateId);
}
