package com.cognizant.genc.cohort57.pod3.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GymMembershipPlanInfoSP {

	@Id
	@Column(name = "PlanId")
	private int planId;

	@Column(name = "PlanName")
	private String planName;

	@Column(name = "Amount")
	private double amount;

	@Column(name = "Duration")
	private int duration;

	public GymMembershipPlanInfoSP() {

	}

	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

}
